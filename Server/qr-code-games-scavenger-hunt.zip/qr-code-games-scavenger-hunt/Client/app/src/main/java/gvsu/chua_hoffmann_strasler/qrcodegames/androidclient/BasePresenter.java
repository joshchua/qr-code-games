package gvsu.chua_hoffmann_strasler.qrcodegames.androidclient;

/**
 * Basic interface for all presenters
 */
public interface BasePresenter {
    void start();
}
