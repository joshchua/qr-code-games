package gvsu.chua_hoffmann_strasler.qrcodegames.androidclient;

/**
 * Basic interface for all views
 */
public interface BaseView<T> {
    void setPresenter(T presenter);
}
