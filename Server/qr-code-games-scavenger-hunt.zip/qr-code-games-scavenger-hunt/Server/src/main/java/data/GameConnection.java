package data;

import com.esotericsoftware.kryonet.Connection;

/**
 *Class defining game connection
 */
public class GameConnection extends Connection{
    public String userName;
    public String gameCode;
}
